# Soheb Ilmoddin Pathan — Portfolio

Simple, fast, responsive portfolio built with HTML, CSS, and minimal JS.

## Run locally

- Open `index.html` in your browser. No build step required.


## Deploy

- diployed HOSTED on   Infinityfree for free web hosting and Domain by GoDaddy which is sohebdevops.co.in






